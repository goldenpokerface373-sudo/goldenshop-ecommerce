{
  "id": 1,
  "date": "25.12.2024 15:30",
  "items": [
    {
      "id": 1,
      "name": "Ноутбук",
      "price": 50000,
      "category": "Электроника",
      "quantity": 1
    }
  ],
  "total": 50000
}