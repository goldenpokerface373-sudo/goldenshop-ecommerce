from flask import Flask, render_template, request, redirect, url_for, flash, session
import json
import os
from datetime import datetime

app = Flask(__name__)
app.secret_key = 'goldenshop_secret_key_2024'

# Файл для данных
DATA_FILE = 'goldenshop_data.json'

# Товары
PRODUCTS = [
    {"id": 1, "name": "Ноутбук", "price": 50000, "category": "Электроника"},
    {"id": 2, "name": "Смартфон", "price": 30000, "category": "Электроника"},
    {"id": 3, "name": "Наушники", "price": 5000, "category": "Электроника"},
    {"id": 4, "name": "Футболка", "price": 1500, "category": "Одежда"},
    {"id": 5, "name": "Джинсы", "price": 3500, "category": "Одежда"},
    {"id": 6, "name": "Книга", "price": 800, "category": "Книги"},
    {"id": 7, "name": "Кофеварка", "price": 7000, "category": "Бытовая техника"},
    {"id": 8, "name": "Кресло", "price": 12000, "category": "Мебель"}
]

# Создаем файл данных если его нет
if not os.path.exists(DATA_FILE):
    with open(DATA_FILE, 'w', encoding='utf-8') as f:
        json.dump({"users": {}}, f, ensure_ascii=False, indent=2)
    print("✅ Файл данных создан")

def load_data():
    """Загрузить данные"""
    try:
        with open(DATA_FILE, 'r', encoding='utf-8') as f:
            data = json.load(f)
            if 'users' not in data:
                data = {'users': {}}
            return data
    except:
        return {'users': {}}

def save_data(data):
    """Сохранить данные"""
    try:
        with open(DATA_FILE, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        return True
    except:
        return False

# Главная страница
@app.route('/')
def index():
    if 'user_id' not in session:
        return redirect('/login')
    
    user_id = session['user_id']
    data = load_data()
    
    if user_id not in data['users']:
        data['users'][user_id] = {"cart": [], "orders": [], "username": user_id}
        save_data(data)
    
    user_data = data['users'][user_id]
    cart_count = len(user_data.get('cart', []))
    
    return render_template('index.html', 
                          products=PRODUCTS, 
                          cart_count=cart_count,
                          username=user_id)

# Страница авторизации
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        
        if not username:
            flash('Введите имя пользователя', 'error')
            return redirect('/login')
        
        data = load_data()
        
        # Создаем пользователя если его нет
        if username not in data['users']:
            data['users'][username] = {
                "cart": [],
                "orders": [],
                "username": username
            }
            save_data(data)
        
        session['user_id'] = username
        flash(f'Добро пожаловать, {username}!', 'success')
        return redirect('/')
    
    return render_template('login.html')

# Выход
@app.route('/logout')
def logout():
    session.pop('user_id', None)
    flash('Вы вышли из системы', 'info')
    return redirect('/login')

# История заказов - РАБОЧАЯ
@app.route('/orders')
def orders():
    if 'user_id' not in session:
        return redirect('/login')
    
    user_id = session['user_id']
    data = load_data()
    
    if user_id not in data['users']:
        return redirect('/login')
    
    user_data = data['users'][user_id]
    orders_list = user_data.get('orders', [])
    cart_count = len(user_data.get('cart', []))
    
    print(f"DEBUG: Пользователь {user_id}, заказов: {len(orders_list)}")
    for order in orders_list:
        print(f"  Заказ #{order.get('id')}, сумма: {order.get('total')}")
    
    return render_template('orders.html', 
                          orders=orders_list, 
                          cart_count=cart_count,
                          username=user_id)

# Корзина - РАБОЧАЯ
@app.route('/cart')
def cart():
    if 'user_id' not in session:
        return redirect('/login')
    
    user_id = session['user_id']
    data = load_data()
    
    if user_id not in data['users']:
        return redirect('/login')
    
    user_data = data['users'][user_id]
    cart_items = user_data.get('cart', [])
    cart_count = len(cart_items)
    
    # Считаем сумму
    total = 0
    for item in cart_items:
        total += item.get('price', 0) * item.get('quantity', 1)
    
    return render_template('cart.html', 
                          cart_items=cart_items, 
                          total=total, 
                          cart_count=cart_count,
                          username=user_id)

# Добавить в корзину - РАБОЧАЯ
@app.route('/add_to_cart', methods=['POST'])
def add_to_cart():
    if 'user_id' not in session:
        return redirect('/login')
    
    user_id = session['user_id']
    product_id = int(request.form.get('product_id', 0))
    
    if product_id <= 0:
        flash('Неверный ID товара', 'error')
        return redirect('/')
    
    # Находим товар
    product = None
    for p in PRODUCTS:
        if p['id'] == product_id:
            product = p
            break
    
    if not product:
        flash('Товар не найден', 'error')
        return redirect('/')
    
    data = load_data()
    
    # Убедимся, что пользователь существует
    if user_id not in data['users']:
        data['users'][user_id] = {
            "cart": [],
            "orders": [],
            "username": user_id
        }
    
    user_data = data['users'][user_id]
    cart_items = user_data.get('cart', [])
    
    # Ищем товар в корзине
    found = False
    for item in cart_items:
        if item['id'] == product_id:
            item['quantity'] = item.get('quantity', 1) + 1
            found = True
            break
    
    # Если не нашли, добавляем новый
    if not found:
        new_item = {
            'id': product['id'],
            'name': product['name'],
            'price': product['price'],
            'category': product['category'],
            'quantity': 1
        }
        cart_items.append(new_item)
    
    # Обновляем корзину
    user_data['cart'] = cart_items
    save_data(data)
    
    flash(f'"{product["name"]}" добавлен в корзину!', 'success')
    return redirect('/')

# Увеличить количество товара в корзине - РАБОЧАЯ
@app.route('/cart/increase/<int:product_id>')
def cart_increase(product_id):
    if 'user_id' not in session:
        return redirect('/login')
    
    user_id = session['user_id']
    data = load_data()
    
    if user_id not in data['users']:
        return redirect('/login')
    
    user_data = data['users'][user_id]
    cart_items = user_data.get('cart', [])
    
    # Ищем товар в корзине
    for item in cart_items:
        if item['id'] == product_id:
            item['quantity'] = item.get('quantity', 1) + 1
            break
    
    # Обновляем корзину
    user_data['cart'] = cart_items
    save_data(data)
    
    flash('Количество товара увеличено', 'success')
    return redirect('/cart')

# Уменьшить количество товара в корзине - РАБОЧАЯ
@app.route('/cart/decrease/<int:product_id>')
def cart_decrease(product_id):
    if 'user_id' not in session:
        return redirect('/login')
    
    user_id = session['user_id']
    data = load_data()
    
    if user_id not in data['users']:
        return redirect('/login')
    
    user_data = data['users'][user_id]
    cart_items = user_data.get('cart', [])
    
    # Ищем товар в корзине
    item_to_remove = None
    for item in cart_items:
        if item['id'] == product_id:
            current_quantity = item.get('quantity', 1)
            if current_quantity > 1:
                item['quantity'] = current_quantity - 1
            else:
                item_to_remove = item
            break
    
    # Удаляем если нужно
    if item_to_remove:
        cart_items.remove(item_to_remove)
        flash('Товар удален из корзины', 'success')
    else:
        flash('Количество товара уменьшено', 'success')
    
    # Обновляем корзину
    user_data['cart'] = cart_items
    save_data(data)
    
    return redirect('/cart')

# Удалить товар из корзины - РАБОЧАЯ
@app.route('/cart/remove/<int:product_id>')
def cart_remove(product_id):
    if 'user_id' not in session:
        return redirect('/login')
    
    user_id = session['user_id']
    data = load_data()
    
    if user_id not in data['users']:
        return redirect('/login')
    
    user_data = data['users'][user_id]
    cart_items = user_data.get('cart', [])
    
    # Ищем товар для удаления
    item_to_remove = None
    for item in cart_items:
        if item['id'] == product_id:
            item_to_remove = item
            break
    
    # Удаляем товар
    if item_to_remove:
        cart_items.remove(item_to_remove)
        flash(f'"{item_to_remove["name"]}" удален из корзины', 'success')
    else:
        flash('Товар не найден в корзине', 'error')
    
    # Обновляем корзину
    user_data['cart'] = cart_items
    save_data(data)
    
    return redirect('/cart')

# Очистить корзину - РАБОЧАЯ
@app.route('/cart/clear')
def cart_clear():
    if 'user_id' not in session:
        return redirect('/login')
    
    user_id = session['user_id']
    data = load_data()
    
    if user_id in data['users']:
        data['users'][user_id]['cart'] = []
        save_data(data)
    
    flash('Корзина очищена', 'success')
    return redirect('/cart')

# Создать заказ из корзины - РАБОЧАЯ
@app.route('/order/create')
def order_create():
    if 'user_id' not in session:
        return redirect('/login')
    
    user_id = session['user_id']
    data = load_data()
    
    if user_id not in data['users']:
        return redirect('/login')
    
    user_data = data['users'][user_id]
    cart_items = user_data.get('cart', [])
    
    if not cart_items:
        flash('Корзина пуста', 'error')
        return redirect('/cart')
    
    # Считаем сумму
    total = 0
    for item in cart_items:
        total += item.get('price', 0) * item.get('quantity', 1)
    
    # Создаем заказ
    new_order = {
        'id': len(user_data.get('orders', [])) + 1,
        'date': datetime.now().strftime('%d.%m.%Y %H:%M'),
        'items': cart_items.copy(),
        'total': total
    }
    
    # Добавляем заказ в историю
    if 'orders' not in user_data:
        user_data['orders'] = []
    
    user_data['orders'].append(new_order)
    
    # Очищаем корзину
    user_data['cart'] = []
    
    # Сохраняем
    save_data(data)
    
    flash(f'Заказ #{new_order["id"]} оформлен на сумму {total} ₽!', 'success')
    return redirect('/orders')

# Повторить заказ - РАБОЧАЯ
@app.route('/order/repeat/<int:order_id>')
def order_repeat(order_id):
    if 'user_id' not in session:
        return redirect('/login')
    
    user_id = session['user_id']
    data = load_data()
    
    if user_id not in data['users']:
        return redirect('/login')
    
    user_data = data['users'][user_id]
    orders_list = user_data.get('orders', [])
    
    # Ищем нужный заказ
    target_order = None
    for order in orders_list:
        if order['id'] == order_id:
            target_order = order
            break
    
    if not target_order:
        flash('Заказ не найден', 'error')
        return redirect('/orders')
    
    cart_items = user_data.get('cart', [])
    
    # Добавляем все товары из заказа в корзину
    for order_item in target_order['items']:
        # Проверяем, есть ли уже такой товар в корзине
        found = False
        for cart_item in cart_items:
            if cart_item['id'] == order_item['id']:
                cart_item['quantity'] = cart_item.get('quantity', 1) + order_item.get('quantity', 1)
                found = True
                break
        
        # Если нет, добавляем новый
        if not found:
            cart_items.append(order_item.copy())
    
    # Обновляем корзину
    user_data['cart'] = cart_items
    save_data(data)
    
    flash('Товары из заказа добавлены в корзину!', 'success')
    return redirect('/cart')

if __name__ == '__main__':
    # УДАЛИТЬ СТАРЫЙ ФАЙЛ ДАННЫХ ЕСЛИ ЕСТЬ ПРОБЛЕМЫ
    if os.path.exists(DATA_FILE):
        try:
            with open(DATA_FILE, 'r', encoding='utf-8') as f:
                old_data = json.load(f)
                # Проверяем структуру
                if 'users' not in old_data:
                    print("⚠️  Старый файл с неправильной структурой, пересоздаю...")
                    os.remove(DATA_FILE)
                    with open(DATA_FILE, 'w', encoding='utf-8') as f:
                        json.dump({"users": {}}, f, ensure_ascii=False, indent=2)
        except:
            os.remove(DATA_FILE)
            with open(DATA_FILE, 'w', encoding='utf-8') as f:
                json.dump({"users": {}}, f, ensure_ascii=False, indent=2)
    
    # Проверяем тестового пользователя
    data = load_data()
    if 'testuser' not in data['users']:
        data['users']['testuser'] = {
            "cart": [
                {"id": 1, "name": "Ноутбук", "price": 50000, "category": "Электроника", "quantity": 1},
                {"id": 3, "name": "Наушники", "price": 5000, "category": "Электроника", "quantity": 2}
            ],
            "orders": [
                {
                    "id": 1,
                    "date": datetime.now().strftime('%d.%m.%Y %H:%M'),
                    "items": [
                        {"id": 2, "name": "Смартфон", "price": 30000, "category": "Электроника", "quantity": 1},
                        {"id": 4, "name": "Футболка", "price": 1500, "category": "Одежда", "quantity": 3}
                    ],
                    "total": 34500
                }
            ],
            "username": "testuser"
        }
        save_data(data)
        print("✅ Тестовый пользователь 'testuser' создан")
    
    print("=" * 50)
    print("🚀 ЗАПУСК GOLDENSHOP")
    print("=" * 50)
    print("🌐 Откройте: http://localhost:5000")
    print("👤 Тестовый пользователь: testuser (любое имя работает)")
    print("📁 Файл данных: goldenshop_data.json")
    print("=" * 50)
    app.run(debug=True, port=5000, use_reloader=False)